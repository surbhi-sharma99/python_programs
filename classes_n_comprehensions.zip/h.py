#Create a list with all values from 1 to 100 squared

"""
li = []

for i in range(1,101):

	if i % 2 == 0
		li.append(i*i)

"""

keys = "q w e r t y u i o p t y a s d f g".split()
values = [85,659,65,87,3,44,65,9,75,98,4,35,9,43,36, 67, 34]


dict =  { keys[i] : values[i] for i in range( len(keys) ) if values[i] % 2 != 0 }


#generator,  itterator, yields,
print(dict)
