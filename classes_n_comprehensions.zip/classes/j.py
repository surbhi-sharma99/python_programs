from imaginary_numbers import Img
print(__name__)

a = Img(5, 7)
b = Img(2, 9)

print(a + b) # 7 + 16i
